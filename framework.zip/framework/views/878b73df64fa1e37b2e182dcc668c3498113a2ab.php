<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>

<table class="table table-borderless table-hover customer_table table-light word">
  <thead> 
    <tr>
      <th>Customer Id</th>
      <th>Full Name</th>
      <th>IC Number</th>
      <th>Tel No</th>
      <th>Email</th>
      <th>License No</th>
      <th></th>
    </tr>
  </thead>
  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($customer->id); ?></td>
    <td><?php echo e($customer->fullName); ?></td>
    <td><?php echo e($customer->icNumber); ?></td>
    <td><?php echo e($customer->telephoneNo); ?></td>
    <td><?php echo e($customer->email); ?></td>
    <td><?php echo e($customer->driverLicenseNumber); ?></td>
    <td><a href="<?php echo e(route('customers.show',$customer->id)); ?>" class="btn btn-secondary">View More</a></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td colspan="7"><?php echo e($customers->links()); ?></td>
  </tr>
</table>

<div class="cancel-btn">
    <a href="<?php echo e(route('home')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thean Chun\Downloads\OoiTheanChun\awap_assignment\resources\views/customers/index.blade.php ENDPATH**/ ?>