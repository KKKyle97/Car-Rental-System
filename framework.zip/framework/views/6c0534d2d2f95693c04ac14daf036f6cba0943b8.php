<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>

<table class="customer_profile_table word">
    <tr>
        <td><img src="<?php echo e(asset('/image_test/test.jpg')); ?>" class="rounded-circle" width="304" height="236"></td>
    </tr>
    <tr>
        <td><h3><?php echo e($customer->fullName); ?></h3></td>
    </tr>
    <tr>
        <td><h5><?php echo e($customer->email); ?></h5></td>
    </tr>
</table>

<div class="customer_profile_detail_container word">
    <div class="customer_profile_detail_box">
        <h4>IC NUMBER</h4>
        <p><?php echo e($customer->icNumber); ?></p>
    </div>

    <div class="customer_profile_detail_box word">
        <h4>TELEPHONE NUMBER</h4>
        <p><?php echo e($customer->telephoneNo); ?></p>
    </div>

    <div class="customer_profile_detail_box word">
        <h4>DRIVING LICENSE</h4>
        <p><?php echo e($customer->driverLicenseNumber); ?></p>
    </div>

    <div class="customer_profile_detail_box word">
        <h4>HOME ADDRESS</h4>
        <p><?php echo e($customer->address); ?>,<?php echo e($customer->city); ?>,<?php echo e($customer->zipCode); ?> <?php echo e($customer->state); ?></p>
        <p></p>
    </div>
    
</div>

<?php if(count($records)==0): ?>
    <div style="margin:auto; width:fit-content; font-size:50px " class="word card">
        <p >No Rental Record!</p>
    </div>
<?php else: ?>
    <table class="table table-borderless table-hover customer_table table-light word">
    <thead> 
        <tr>
        <th>Order Id</th>
        <th>Rental Date</th>
        <th>Payment</th>
        <th></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($record->id); ?></td>
        <td><?php echo e($record->rentStartDate); ?> - <?php echo e($record->rentEndDate); ?></td>
        <td>RM<?php echo e($record->total); ?></td> 
        <td><a href="<?php echo e(route('rentals.show',$record->id)); ?>" ><button class="btn btn-secondary word">View More</button></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php endif; ?>

<div class="cancel-btn">
    <?php if(Auth::user()->roles=='admin'): ?>
    <a href="<?php echo e(route('customers.index')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
    <?php else: ?>
    <a href="<?php echo e(route('home')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WeiSeng\Desktop\OoiTheanChun\awap_assignment\awap_assignment\resources\views/customers/show.blade.php ENDPATH**/ ?>