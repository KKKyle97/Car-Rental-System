<?php $__env->startSection('content'); ?>
<div class="container word">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Hi <?php echo e(Auth::user()->name); ?>! Welcome to car renting system! 
                </div>
                
            </div>
            <?php if(Auth::user()->roles == "admin"): ?>
            <div class="card card-margin">
                <div class="card-header">Car Management</div>

                <div class="card-body ">
                    <a href=" <?php echo e(route('cars.create')); ?> "><button class="btn btn-success word">Register New Car</button></a>
                    <a href=" <?php echo e(route('cars.index')); ?> "><button class="btn btn-warning word">Manage Car</button></a>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Auth::user()->roles == "admin"): ?>
            <div class="card card-margin">
                <div class="card-header">Customer Management</div>

                <div class="card-body">
                    <a href="<?php echo e(route('customers.index')); ?>"><button class="btn btn-secondary word">View Customer Profile</button></a> 
                </div>
            </div>

            <div class="card card-margin">
                <div class="card-header">Rent Order Management</div>

                <div class="card-body">
                    <a href="<?php echo e(route('rentals.index')); ?>"><button class="btn btn-secondary word">View Rent Order</button></a>
                </div>
            </div>
            <?php else: ?>
            <div class="card card-margin">
                <div class="card-header">Profile Management</div>

                <div class="card-body">
                    <a href="<?php echo e(route('customers.show',Auth::user()->id)); ?>"><button class="btn btn-secondary word">View Profile</button></a>
                    <a href="<?php echo e(route('customers.edit',Auth::user()->id)); ?>"><button class="btn btn-secondary word">Edit Profile</button></a>
                </div>
            </div>

            <div class="card card-margin">
                <div class="card-header">Rent Order Management</div>

                <div class="card-body">
                    <a href="<?php echo e(route('rentals.view',Auth::user()->id)); ?>"><button class="btn btn-secondary word">View Rent Order</button></a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
   var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
    alert(msg);
    }</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yee Choong\Desktop\awap_assignment\awap_assignment\resources\views/home.blade.php ENDPATH**/ ?>