<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>
<style>

.label{
    color:white;
    font-size:20px;
}

</style>

<?php if((Auth::user()->roles=='admin') && (count($orders)>0)): ?>
<table class="table table-borderless table-hover customer_table table-light word ">
    <thead> 
        <tr>
        <th>Order Id</th>
        <th>Customer Name</th>
        <th>Car</th>
        <th>Rental Date</th>
        <th>Payment</th>
        <th></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->id); ?></td>
        <td><?php echo e($order->customer->fullName); ?></td>
        <td><?php echo e($order->car->make); ?> <?php echo e($order->car->model); ?></td>
        <td><?php echo e($order->rentStartDate); ?> - <?php echo e($order->rentEndDate); ?></td>
        <td>RM<?php echo e($order->total); ?></td> 
        <td><a href="<?php echo e(route('rentals.show',$order->id)); ?>" class="btn btn-secondary">View More</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php else: ?>
<div class="cancel-btn word">
    <p>No record found</p>
</div>

<?php endif; ?>

<div class="cancel-btn">
<?php echo e($orders->links()); ?>

</div>


<div class="cancel-btn">
    <a href="<?php echo e(route('home')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thean Chun\Downloads\OoiTheanChun\awap_assignment\resources\views/rentals/index.blade.php ENDPATH**/ ?>