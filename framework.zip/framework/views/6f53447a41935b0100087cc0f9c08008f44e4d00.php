<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="show_specific_car_container word">
                    <div class="show_specific_car_box ">
                        <table class="table table-borderless">
                            <tr  style="text-align:center">
                                <td colspan='2'><img style="margin:auto" src="<?php echo e(asset('storage/Cars/'.$car->photo)); ?>" width="200px" height="150px"></td>
                            </tr>
                            <tr>
                                <td>Manufacturer:</td>
                                <td><?php echo e($car->make); ?></td>
                            </tr>
                            <tr>
                                <td>Model:</td>
                                <td><?php echo e($car->model); ?></td>
                            </tr>
                            <tr>
                                <td>Car Plate Number:</td>
                                <td><?php echo e($car->carPlateNo); ?></td>
                            </tr>
                            <tr>
                                <td>Year:</td>
                                <td><?php echo e($car->carYear); ?></td>
                            </tr>
                            <tr>
                                <td>Category:</td>
                                <td><?php echo e(Common::$category[$car->category]); ?></td>
                            </tr>
                            <tr>
                                <td>Rate Per Day:</td>
                                <td>RM<?php echo e($car->ratePerDay); ?></td>
                            </tr>
                            <tr>
                                <td>Description:</td>
                                <td><?php echo e($car->description); ?></td>
                            </tr>

                        </table>
                        <div class="action_button">
                            <a href=" <?php echo e(route('cars.index')); ?> " class="btn btn-primary word">Back</a>
                            <a href="<?php echo e(route('cars.edit',$car->id)); ?>" class="btn btn-warning word">Edit</a>
                            <form method="post" action="<?php echo e(route('cars.destroy',$car->id)); ?>" style="width:fit-content; float:right; margin-left:5px;" >
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Delete" class="btn btn-danger word"/>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yee Choong\Desktop\awap_assignment\awap_assignment\resources\views/cars/show.blade.php ENDPATH**/ ?>