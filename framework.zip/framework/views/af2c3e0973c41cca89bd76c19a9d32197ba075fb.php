<?php 
use App\Common;
?>



<?php $__env->startSection('content'); ?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>


.center{
    margin-left:20%;
    margin-top:10%;
    margin-right:20%;
}


.main_menu {
  border-radius: 25px;
  margin-bottom:10px;
  overflow:auto;
}

.menu {
  width: 25%;
  float: left;
  padding:3%;

}

.menu-price {
  width: 30%;
  float: right;
  padding: 3%;
}

.menu-pricing {
    padding-right: 30%;
    font-size: 1.4vw;
    text-align: end;
  }

.main {
  width: 40%;
  float: left;
  padding-left: 3%;

}



</style>

<body onload ="setIndex()">

<div class="justify-content-center" >
  <div class="col-md-8" style=" margin:auto;">
      <div class="card">
          <div class="container word" style="padding:5%;">
            <div class="panel-body" style="overflow:auto;" >
              <div class="col-sm-4" style="float:left;">
                <label>Category:</label>
                <?php $__currentLoopData = Common::$category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row">
                    <div class="col-sm-7">
                    <input type="radio" name="Category" value="<?php echo e($key); ?>" onclick="document.location.href='<?php echo route("rentals.sort",array('category'=>$key,'car_name'=>$car_name,'pickup_date' =>$pickup_date,'return_date'=>$return_date,'sorts'=>$sorts)); ?>'"><?php echo e($value); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="col-sm-6 " style="float:right;">
                <form method="get" action="<?php echo e(route('rentals.search')); ?>">
                  <div class="form-group row">
                    <?php echo Form::label('car-name','Car Name',['class' => 'control-label col-sm-3']); ?>

                      <div class="col-sm-7">
                        <?php echo Form::text('car_name', $car_name,[
                        'class' => 'form-control',
                        'placeholder' =>'Enter Car Name (Optional)']); ?>

                      </div>
                  </div>

                  <div class="form-group row" >
                    <?php echo Form::label('start-date','Pickup Date',['class' => 'control-label col-sm-3']); ?>

                      <div class="col-sm-7">
                        <?php echo Form::date('pickup_date', $pickup_date,[
                        'class' => 'form-control',
                        'id' => 'from',
                        'onchange' => 'validateDate()']); ?>

                      </div>
                  </div>

                  <div class="form-group row">
                    <?php echo Form::label('return date','Return Date',['class' => 'control-label col-sm-3']); ?>

                      <div class="col-sm-7">
                        <?php echo Form::date('return_date', $return_date,[
                        'class' => 'form-control',
                        'id' => 'to',
                        'onchange' => 'validateDate()']); ?>

                      </div>
                  </div>

                <!-- Hidden Input to Pass into parameter -->
                <input type="text" name="category" value="<?php echo $category; ?>" hidden></input>
                <input type="text" name="sorts" value="<?php echo $sorts; ?>" hidden></input>

                  <?php echo Form::button('Search',[
                  'type' => 'submit',
                  'class' => 'btn btn-primary word']); ?>


                </form>
              </div>
            </div>



            <?php if(count($car) > 0): ?>
            <div class="container">
              <div class="form-group row">
                <div class="col-sm-4" >
                  <select class="form-control" id="car_sorting" onchange="car_Sorting()">
                    <option value= "price_asc">Sort By Price: Low To High</option>
                    <option value= "price_desc">Sort By Price: High To Low</option>
                    <option value= "model_asc">Sort By Model: A-Z</option>
                    <option value= "model_desc">Sort By Model: Z-A</option>
                  </select>
                </div>
              </div>
              <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width:100%;height:20%" >
                  <div class ="main_menu">
                    <div class="menu ">
                      <?php if(Storage::disk('public')->exists('Cars/'.$cars->photo)): ?>
                        <img src ="/storage/Cars/<?php echo e($cars->photo); ?>" width="150" height="100"  style="margin:10px;" >
                      <?php endif; ?>
                    </div>
                    
                    <div class = "main">
                      <h3><?php echo e($cars->make); ?> <?php echo e($cars->model); ?></h3>
                      <p><?php echo e(Common::$category[$cars->category]); ?> Category</p>
                      <p>Year <?php echo e($cars->carYear); ?></p>
                      <p><?php echo e($cars->description); ?></p>         
                    </div>

                    <div class = "menu-price">
                        <div style="padding-left:30%;padding-right:30%;padding-top:10%">
                          <a href='<?php echo route("rentals.create",array('id'=>$cars->id,'pickup_date' =>$pickup_date,'return_date'=>$return_date)); ?>'>
                          <button class='btn btn-warning word'>Select</button></a>
                          <h5>RM<?php echo e($cars->ratePerDay); ?></h5>
                      </div>
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="cancel-btn">
              <span><?php echo e($car->links()); ?></span>
              </div>
              
            </div>
            <?php else: ?>
            <script>alert('No Car is Found')</script>
            <?php endif; ?>

          </div>
      </div>
  </div>
</div>
</body>


<script>

var today = new Date().toISOString().split('T')[0];
 document.getElementsByName("pickup_date")[0].setAttribute('min', today);

function validateDate()
{
 var today = new Date().toISOString().split('T')[0];
 document.getElementsByName("pickup_date")[0].setAttribute('min', today);

 var current_day = new Date(today); 
 var selected_start_date = new Date(document.getElementById('from').value);
 var selected_end_date = new Date(document.getElementById('to').value);

 var start_date =  new Date(selected_start_date).toISOString().split('T')[0];
 document.getElementsByName("return_date")[0].setAttribute('min', start_date);


    if(selected_end_date<selected_start_date)
    {
        document.getElementById('to').value = null;
    }

    if(selected_start_date<current_day)
    {
        document.getElementById('from').value = null;
    }

}

  function car_Sorting()
  {
    var e = document.getElementById("car_sorting");
    var value = e.options[e.selectedIndex].value;
    if (value=="price_asc")
    {
      document.location.href="<?php echo route("rentals.sort",array('category'=>$category,'car_name'=>$car_name,'pickup_date' =>$pickup_date,'return_date'=>$return_date,'sorts'=>'price_asc')); ?>";
    }
    else if(value=="price_desc")
    {
      document.location.href="<?php echo route("rentals.sort",array('category'=>$category,'car_name'=>$car_name,'pickup_date'=>$pickup_date,'return_date'=>$return_date,'sorts'=>'price_desc')); ?>";
    }
    else if(value=="model_asc")
    {
      document.location.href="<?php echo route("rentals.sort",array('category'=>$category,'car_name'=>$car_name,'pickup_date'=>$pickup_date,'return_date'=>$return_date,'sorts'=>'model_asc')); ?>";
    }
    else if(value=="model_desc")
    {
      document.location.href="<?php echo route("rentals.sort",array('category'=>$category,'car_name'=>$car_name,'pickup_date'=>$pickup_date,'return_date'=>$return_date,'sorts'=>'model_desc')); ?>";
    }
  }

  function setIndex()
  {
    var index = 0 ;
    var sorts = "<?php echo $sorts ?>";

    var category = document.getElementsByName('Category'); 
    for(i = 0; i < category.length; i++)
    { 
      if(category[i].value== <?php echo $category?> ) 
      {
        category[i].checked = true;
      }
    } 

    if (sorts == "price_desc")
    {
        index = 1;
    }
    else if(sorts == "model_asc")
    {
      index =2;
    }
    else if(sorts == "model_desc")
    {
      index = 3;
    }
    document.getElementById('car_sorting').selectedIndex = index;

    
  }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thean Chun\Downloads\OoiTheanChun\awap_assignment\resources\views/rentals/results.blade.php ENDPATH**/ ?>