<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>

<div class="display_all_car_wrapper">
   <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="display_single_car_box word">
        <ul>
            <li><img src="storage/Cars/<?php echo e($car->photo); ?>" width="200px" height="150px" style="margin-bottom:10px"></li>
            
            <li>Manufacturer: <?php echo e($car->make); ?></li>
            <li>Model: <?php echo e($car->model); ?></li>
            <li>Car Plate Number: <?php echo e($car->carPlateNo); ?></li>
            <li>Year: <?php echo e($car->carYear); ?></li>
            <li>Rate/Day:RM<?php echo e($car->ratePerDay); ?></li>
        </ul>
        <div class="action_button">
            <a href="<?php echo e(route('cars.show',$car->id)); ?>" class="btn btn-primary word">View</a>
            <a href="<?php echo e(route('cars.edit',$car->id)); ?>" class="btn btn-warning word">Edit</a>
            <form method="post" action="<?php echo e(route('cars.destroy',$car->id)); ?>" style="width:fit-content; float:right; margin-left:5px;" onSubmit="return confirm('Are you sure you wish to delete?');" >
            <?php echo e(method_field('DELETE')); ?>

            <?php echo e(csrf_field()); ?>

                <input type="submit" value="Delete" class="btn btn-danger word"/>
            </form>
            
        </div>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="cancel-btn">
<?php echo e($cars->links()); ?>

</div>

<div class="cancel-btn">
    <a href="<?php echo e(route('home')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
</div>

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yee Choong\Desktop\awap_assignment\awap_assignment\resources\views/cars/index.blade.php ENDPATH**/ ?>