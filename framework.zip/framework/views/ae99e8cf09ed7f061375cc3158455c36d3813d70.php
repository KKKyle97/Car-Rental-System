<?php 

use App\Common;

?>

<?php $__env->startSection('content'); ?>

<table class="table table-bordered table-hover customer_table">
    <thead class="thead-light"> 
        <tr>
        <th>Order Id</th>
        <th>Customer Name</th>
        <th>Car</th>
        <th>Rental Date</th>
        <th>Payment</th>
        <th></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->id); ?></td>
        <td><?php echo e($order->customer->fullName); ?></td>
        <td><?php echo e($order->car->make); ?> <?php echo e($order->car->model); ?></td>
        <td><?php echo e($order->rentStartDate); ?> - <?php echo e($order->rentEndDate); ?></td>
        <td>RM<?php echo e($order->total); ?></td> 
        <td><a href="<?php echo e(route('rents.show',$order->id)); ?>" class="btn btn-primary">View More</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\awap_assignment\resources\views/rents/index.blade.php ENDPATH**/ ?>