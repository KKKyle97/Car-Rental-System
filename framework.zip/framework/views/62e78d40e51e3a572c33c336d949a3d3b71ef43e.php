<?php 

use App\Common;
use App\Customer;
?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="show_specific_rental_container word">
                        <table class="table table-borderless">
                            <tr  style="text-align:center">
                                <td colspan='2'><img style="margin:auto" img src ="/storage/Cars/<?php echo e($rental->car->photo); ?>" width="200px" height="150px"></td>
                            </tr>
                            <tr>
                                <td>Order ID:</td>
                                <td><?php echo e($rental->id); ?></td>
                            </tr>
                            <tr>
                                <td>Car:</td>
                                <td><?php echo e($rental->car->model); ?></td>
                            </tr>
                            <tr>
                                <td>Car Plate Number:</td>
                                <td><?php echo e($rental->car->carPlateNo); ?></td>
                            </tr>
                            <tr>
                                <td>Year:</td>
                                <td><?php echo e($rental->car->carYear); ?></td>
                            </tr>
                            <tr>
                                <td>Category:</td>
                                <td><?php echo e(Common::$category[$rental->car->category]); ?></td>
                            </tr>
                            <tr>
                                <td>Rent date:</td>
                                <td><?php echo e($rental->rentStartDate); ?> - <?php echo e($rental->rentEndDate); ?></td>
                            </tr>
                            <tr>
                                <td>Total Price paid:</td>
                                <td>RM<?php echo e($rental->total); ?></td>
                            </tr>
                            <tr>
                                <td>Customer Name:</td>
                                <td><?php echo e($rental->customer->fullName); ?></td>
                            </tr>
                            <tr>
                                <td>Customer IC:</td>
                                <td><?php echo e($rental->customer->icNumber); ?></td>
                            </tr>
                            <tr>
                                <td>Customer Phone Number:</td>
                                <td><?php echo e($rental->customer->telephoneNo); ?></td>
                            </tr>

                        </table>
                    </div>
            </div>
        </div>
    </div>

    <div class="cancel-btn">
    <?php if(Auth::user()->roles=='admin'): ?>
    <a href="<?php echo e(route('rentals.index')); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
    <?php else: ?>
    <a href="<?php echo e(route('customers.show',Auth::user()->email)); ?>"  class="btn btn-primary word" style="margin:auto; width:fit-content;">Back</a>
    <?php endif; ?>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thean Chun\Downloads\OoiTheanChun\awap_assignment\resources\views/rentals/show.blade.php ENDPATH**/ ?>