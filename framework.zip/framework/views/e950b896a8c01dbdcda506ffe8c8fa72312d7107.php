<?php 
use App\Customer;
?>

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Car Rental')); ?></title>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- Styles -->


    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/backend.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/nav.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body style="background-image:url(<?php echo e(asset('/image_test/background.jpg')); ?>); background-size:100% 100%; background-repeat:no-repeat; min-height:100vh;">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light shadow-sm">
            <div class="container">
                <a class="navbar-brand navbar-head" href="<?php echo e(route('welcome')); ?>">
                    Car Rental System
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link navbar-word" href="<?php echo e(route('login')); ?>" style="color:black;"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="navbar-word nav-link " href="<?php echo e(route('register')); ?>" style="color:black;"><?php echo e(__('Register')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',App\RentalOrder::class)): ?>
                            <li class="nav-item">
                                <a id="navbarDropdown"  style="color:black;" class="nav-link navbar-word" href="<?php echo route('rentals.book'); ?>" role="button"  aria-haspopup="true" aria-expanded="false" v-pre>
                                    Book 
                                </a>
                            </li>

                            <li class="nav-item">
                                <a id="navbarDropdown"  style="color:black;" class="nav-link navbar-word" href="<?php echo route('rentals.view'); ?>" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                                    View Order 
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->can('update', Customer::where('email',Auth::user()->email)->first())): ?>
                            <li class="nav-item">
                                <a id="navbarDropdown" class="nav-link navbar-word" style="color:black;" role="button" aria-haspopup="true" aria-expanded="false" v-pre
                                    href="<?php echo e(route('customers.edit',Auth::user()->email)); ?>">
                                    <?php echo e(__('Edit Profile')); ?>

                                </a>
                            </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a id="navbarDropdown"  style="color:black;" class="nav-link navbar-word" href="<?php echo route('rentals.gallery'); ?>" role="button"  aria-haspopup="true" aria-expanded="false" v-pre>
                                    Car gallery 
                                </a>
                            </li>

                        <li class="nav-item">
                            <a id="navbarDropdown" class="nav-link navbar-word" style="color:black;" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                        </li>

                            <li class="nav-item">
                            <a class="navbar-word nav-link " href="<?php echo e(route('home')); ?>" style="color:black;">Home</a>
                        </li>
                    

                            <li class="nav-item">
                                <a id="navbarDropdown" class="nav-link navbar-word" style="color:black;" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4" style="text-transform:uppercase;">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>

</html><?php /**PATH C:\Users\WeiSeng\Desktop\OoiTheanChun\awap_assignment\awap_assignment\resources\views/layouts/app.blade.php ENDPATH**/ ?>