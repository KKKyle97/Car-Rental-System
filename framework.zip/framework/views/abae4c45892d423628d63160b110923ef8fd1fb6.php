<?php 

use App\Common;

?>


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edit Profile')); ?></div>
                <div class="card-body">
                    <form action="<?php echo e(route('customers.update',$customer->id)); ?>" method="POST" onSubmit="return confirm('Are you sure you wish to update the info?');">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label>Full Name:</label>
                            <input type="text" class="form-control" name="fullName" value="<?php echo e($customer->fullName); ?>"
                                disabled />
                        </div>
                        <div class="form-group row" id="current_make">
                            <label>IC Number:</label>
                            <input type="text" class="form-control" name="icNumber" value="<?php echo e($customer->icNumber); ?>"
                                disabled />
                        </div>
                        <div class="form-group row">
                            <label>Driver License Number:</label>
                            <input type="text" class="form-control" name="driverLicenseNumber"
                                value="<?php echo e($customer->driverLicenseNumber); ?>" disabled />
                        </div>
                        <div class="form-group row">
                            <label>Email:</label>
                            <input type="text" class="form-control"  name="email"
                                value="<?php echo e($customer->email); ?>" disabled/>
                        </div>
                        <div class="form-group row">
                            <label>Telephone Number:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['telephoneNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="telephoneNo" value="<?php echo e($customer->telephoneNo); ?>" maxlength="10" />
                            <?php $__errorArgs = ['telephoneNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <label>Address:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="address" value="<?php echo e($customer->address); ?>" maxlength="100" />
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <label>City:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city"
                                value="<?php echo e($customer->city); ?>" />
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <label>State:</label>
                            <?php echo Form::select('state',Common::$states,$customer->state,[
                            'class' => 'form-control',
                            ]); ?>

                        </div>
                        <div class="form-group row">
                            <label>Zip Code:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['zipCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="zipCode" value="<?php echo e($customer->zipCode); ?>" maxlength="5" />
                            <?php $__errorArgs = ['zipCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <input type="submit" class="btn btn-success word" href="<?php echo e(route('home')); ?>" />
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary word">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thean Chun\Downloads\OoiTheanChun\awap_assignment\resources\views/customers/edit.blade.php ENDPATH**/ ?>